#pragma once
#include "event.h"
class Chocolate : public EventInterface{
public:
    int mood;
public:
    Chocolate() : EventInterface() {
        mood = 0;
    } 
    virtual void zoo(EventInterface*);
    virtual void shop(EventInterface*);
    virtual void birthday();
    
};

class Strawberry : public EventInterface{
public:
    int mood;
public:
    Strawberry() : EventInterface() {
        mood = 0;
    } 
    virtual void zoo(EventInterface*);
    virtual void shop(EventInterface*);
    virtual void birthday();
    
};
