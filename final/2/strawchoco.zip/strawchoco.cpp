#include "strawchoco.h"
void Chocolate::zoo(EventInterface *)
{
    increase_mood(5);
}

void Chocolate::shop(EventInterface *)
{
    increase_mood(1);
}


void Chocolate::birthday() 
{
    
}

void Strawberry::zoo(EventInterface*) 
{
    increase_mood(1);

}

void Strawberry::shop(EventInterface*) {
    increase_mood(5);

}


void Strawberry::birthday()
{

}
